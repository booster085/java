import java.util.ArrayList;
import java.util.Scanner;

public class BePositive_Broken {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scn = new Scanner(System.in);
		
		int countSequences = scn.nextInt();
		//Fixed -> Move to next line
		scn.nextLine();
		
		for (int i = 0; i < countSequences; i++) {
			String[] input = scn.nextLine().trim().split(" ");
			ArrayList<Integer> numbers = new ArrayList<>();
			
			for (int j = 0; j < input.length; j++) {
				if (!input[j].equals("") ) {
					//Fixed i to j
					int num = Integer.parseInt(input[j]);
					numbers.add(num);	
				}							
			}
			
			boolean found = false;
			
			for (int j = 0; j < numbers.size(); j++) {				
				int currentNum = numbers.get(j);
				//Changed ">" to ">="
				if (currentNum >= 0) { 
					//Fixed == to !=
					System.out.printf("%d%s", currentNum, (j != (numbers.size() - 1)) ? " " : "\n");
					found = true;
				} else {
					//Added check of next index exists
					if(j + 1 <= numbers.size() - 1) {
					currentNum += numbers.get(j + 1);	
					//Added j increment
					j++;
					}
					//Changed '>' to '>='
					if (currentNum >= 0) {
						//Changed '==' to '!='
						System.out.printf("%d%s", currentNum, j != numbers.size() - 1 ? " " : "\n");
						found = true;
					}					
				}
			}
			
			if (!found) {
				System.out.println("(empty)");
			} 			
		}		
	}
}
