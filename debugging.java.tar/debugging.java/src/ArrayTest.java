package ArrayTest;

import java.util.Scanner;

public class ArrayTest {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scn = new Scanner(System.in);	
		
		int sizeOfArray = scn.nextInt();
		long[] array = new long[sizeOfArray];
		//Fixed move to next line
		scn.nextLine();
		for (int i = 0; i < array.length; i++) {
			
			array[i] = scn.nextLong(); 
		}
		
		String command = scn.next();
		//Changed command to from "over" to "stop"
		while (!command.equals("stop")) {
			String line = scn.nextLine().trim();
			int[] params = new int[2];
			//Changed command from "substract" to "subtract"
			if(command.equals("add") || command.equals("subtract") || command.equals("multiply")) {
				String[] stringParams = line.split(" ");
				params[0] = Integer.parseInt(stringParams[0]);
				params[1] = Integer.parseInt(stringParams[1]);

				performAction(array, command, params);
			//Added else statement
			} else {
				performAction(array, command, params);
				
				
			}
			printArray(array);
			System.out.print('\n');
			command = scn.next();				
		}		
	}
	//Fixed return long Array
	static void performAction(long[] array, String action, int[] params){
		//Removed cloned aray
		int pos = params[0] - 1;
		int value = params[1];

		switch (action) {
		case "multiply":
			array[pos] *= value;
			break;
		case "add":
			array[pos] += value;
			break;
		case "subtract":
			array[pos] -= value;
			break;
		case "lshift":
			arrayShiftLeft(array);
			break;
		case "rshift":
			arrayShiftRight(array);
			break;
		}
	}
	private static void arrayShiftRight(long[] array) {
		//Put last element into temp variable
		long tempValue = array[array.length - 1];
		for (int i = array.length-1; i >= 1 ; i--) {
			array[i] = array[i - 1];
		}
		//Set last element to first position
		array[0] = tempValue;
	}
	private static void arrayShiftLeft(long[] array) {
		//Put first element to temp variable
		long tempValue = array[0];
		for (int i = 0; i < array.length - 1; i++) {
			array[i] = array[i+1];
		}
		//Set first element to last position
		array[array.length -1] = tempValue;
	}

	private static void printArray(long[] array) {
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}
}