package InstructionSet;

import java.util.Scanner;

public class InstructionSet_Broken {
    
    public static void main(String[] args) {
    	
        Scanner input = new Scanner(System.in);
        String opCode = input.nextLine(); 
        //Set every number to long
        while (!opCode.equals("END")) {
            String[] codeArgs = opCode.split(" ");

            long result = 0;
            switch (codeArgs[0]) {
                case "INC": {
                	//Set integer to long type
                    long operandOne = Long.parseLong(codeArgs[1]);
                    //Fixed increment to prefix
                    result = ++operandOne;
                    break;
                }
                case "DEC": {
                	//Set integer to long type
                    long operandOne = Long.parseLong(codeArgs[1]);
                    //Fixed decrement to prefix
                    result = --operandOne;
                    break;
                }
                case "ADD": {
                	//Set integer to long type
                    long operandOne  = Long.parseLong(codeArgs[1]);
                    long operandTwo = Long.parseLong(codeArgs[2]);
                    result = operandOne + operandTwo;
                    break;
                }
                case "MLA": {
                	//Set integer to long type
                    long operandOne  = Long.parseLong(codeArgs[1]);
                    long operandTwo = Long.parseLong(codeArgs[2]);
                    result = operandOne * operandTwo;
                    break;
                }
                default:
                    break;
            }

            System.out.println(result);
            //Added input read for END after the loop
            opCode = input.nextLine();
        }
    }
}
