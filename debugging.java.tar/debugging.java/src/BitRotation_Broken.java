package BitRotation;

import java.util.Scanner;

public class BitRotation_Broken {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //Changed type Byte to type Int
        int number = Integer.parseInt(input.nextLine());
        int rotations = Integer.parseInt(input.nextLine());

        for (int i = 0; i < rotations; i++) {
            String direction = input.nextLine();
            //Replace '==' with equals because String is referent type
            if (direction.equalsIgnoreCase("right")) {
                int rightMostBit = number & 1;
                number >>= 1;
        		//Changed from 6 to 5 
                number |= rightMostBit << 5;
              //Replace '==' with equals because String is referent type
            } else if (direction.equalsIgnoreCase("left")) {
            	//Changed from 6 to 5
                int leftMostBit = (number >> 5) & 1;
                number <<= 1;
                number |= leftMostBit;
                //Removed 7th bit from the left because we need only 6 bits 
                number &= 63;
            }
        }

        System.out.println(number);
    }
}
